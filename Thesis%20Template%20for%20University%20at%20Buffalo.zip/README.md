# VJTIThesis
These are latex template files for students at Veermata Jijabai Technological Institute (VJTI) to prepare their thesis/dissertation according to VJTI's guidelines.
